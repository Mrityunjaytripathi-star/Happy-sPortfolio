# Vibecraft Frames – Video Editor Portfolio
Owner: Happy Raj Gupta

## What is in this zip
```
vibecraft-frames/
├── index.html      ← THE WHOLE WEBSITE IN ONE FILE (HTML + CSS + JavaScript + profile photo)
├── README.md
└── source/         ← the same site split into separate files (css/, js/, tools/, build_single.py)
```

## Open / publish
- Open `index.html` by double-click. Nothing to install.
- Publish: upload only `index.html` (e.g. Netlify Drop, GitHub Pages). It works on its own.
- Fonts load from Google Fonts when online; offline the browser uses its default fonts.

## Edit
- Contact links (Instagram, WhatsApp, phone, email): search `l-ig`, `l-wa`, `l-ph`, `l-em` in `index.html`.
- Services, portfolio, skills, tools, email: the `CONTENT & SETTINGS` block inside the `<script>`.
- Your own videos (permanent): put the .mp4 next to `index.html` in a folder `assets/videos/` and set its path as the 4th item of an entry in `WORKS`, e.g. `"assets/videos/travel.mp4"`. YouTube/Drive/Instagram links also work (open in a new tab).
- Prefer editing separate files? Work in `source/`, then run `python3 build_single.py` to regenerate `index.html`.
